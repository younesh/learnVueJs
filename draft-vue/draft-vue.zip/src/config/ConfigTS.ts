export default class ConfigTS {
    static nameApp  = "app test globale"; 
}